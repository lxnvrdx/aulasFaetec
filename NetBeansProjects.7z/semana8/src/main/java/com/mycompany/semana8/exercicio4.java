
package com.mycompany.semana8;

import java.util.Scanner;


public class exercicio4 {
     public static void main(String[]args){
     Scanner ler = new Scanner(System.in);
     String []nome;
     nome= new String[33];
     
     int i, velha=0,cont = 0;
     String nvelha = null;
     int[]a;
     a= new int[5];
 
        for(i = 0; i < 5; i++){
             System.out.println("informe seu nome : ");
             nome[i] = ler.next();
            
            System.out.println("Informe sua idade :");
            a[i]= ler.nextInt();
            
            if(a[i]>velha){
            velha=a[i];
            nvelha=nome[i];
            } 
            
            if(a[i]<18){
            cont=cont+1;
            } 
        }

            System.out.println("===================================");
          
            System.out.println(">> Quantidade de pessoas com idade menor que 18 anos:   "+cont);
           
            System.out.println(">> A pessoa mais velha se chama:    "+nvelha);
            
           
            }}
 

    




