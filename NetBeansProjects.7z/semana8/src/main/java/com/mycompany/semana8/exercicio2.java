
package com.mycompany.semana8;

import java.util.Scanner;

public class exercicio2 {
    public static void main(String[]args){
        Scanner ler = new Scanner(System.in);
        int []n;
        int i, contador = 0;

        n = new int[10];

        for(i = 0; i < 10; i++){
            System.out.println("Informe um numero: ");
            n[i]= ler.nextInt();

            if ((n[i] % 2) == 0){
                contador=contador+1;

            }
        }
        System.out.println("==============================================================================");
        System.out.println("\nO(s) número(s) pare(s) é(sao): "+contador);
    }
}
