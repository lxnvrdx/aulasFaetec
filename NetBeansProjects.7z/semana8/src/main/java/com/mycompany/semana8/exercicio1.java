/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.semana8;
 
import java.util.Scanner;

public class exercicio1 {
    
    public static void main(String[]args){
        Scanner ler = new Scanner(System.in);

        int num, maior=0, menor = 10000, i;
 
         int[]a;
     
            a= new int[10];
 
        for(i = 0; i < 10; i++){
            System.out.printf("Digite um numero:");
            a[i]= ler.nextInt();
 
            if(a[i] > maior){ 
                maior= a[i];
            }
            if(a[i] < menor){ 
                menor= a[i];
            }
        }

        System.out.printf ("\nO menor numero e: "+menor);
        System.out.printf ("\nE o maior numero e: "+maior);
    }
}
