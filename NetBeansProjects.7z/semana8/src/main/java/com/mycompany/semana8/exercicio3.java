
package com.mycompany.semana8;
 
import java.util.Scanner;

public class exercicio3 {

 public static void main(String[]args){
     Scanner ler = new Scanner(System.in);
     String []nomecli;
     nomecli= new String[33];
     int i;
       int[]a;
     
            a= new int[5];
 
        for(i = 0; i < 5; i++){
            System.out.println("Informe o telefone :");
            a[i]= ler.nextInt();
             System.out.println("informe o nome do cliente: ");
             nomecli[i] = ler.next();
           
            }

     
      for(i = 0; i < 5; i++){
           System.out.println("==============================================================================");
          
            System.out.println("Numero de telefone do cliente:   "+a[i]);
           
             System.out.println("Nome do cliente:    "+nomecli[i]);
            
           
            }
 }

    
}


