
package com.mycompany.semana9ex3;


public class CalculadoraTeste {
	public static void main(String[] args) {
		
		Calculadora calc;
            calc = new Calculadora();
		
			System.out.println(calc.soma(56, 69));
			
			System.out.println(calc.sub(69, 58));
			
			System.out.println(calc.multi(5, 5));
			
			System.out.println(calc.div(10, 2));
			
			System.out.println(calc.raizQuadrada(49));
			
			System.out.println(calc.potencia(6, 5));
				
	}
}
