
package com.mycompany.semana6;



import java.util.Arrays;
import java.util.Scanner;

public class Exercicio4 {
        public static void main(String[]args){
            Scanner ler = new Scanner(System.in);
            int i, maior, menor, soma;
            int[]a;
     
            a= new int[3];
            
                for(i=1;i<4;i++){
                System.out.println("Informe o  "+i+"  numero");
                a[i]= ler.nextInt();
                
                    
                }
                 for(i=1;i<4;i++){
                System.out.println("Informe o primeiro numero: ");
           
                
                  }
   
              
                


        }}