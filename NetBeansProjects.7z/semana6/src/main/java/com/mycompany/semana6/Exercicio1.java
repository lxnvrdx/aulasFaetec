
package com.mycompany.semana6;

import java.util.Scanner;

public class Exercicio1 {
    public static void main(String[]args){
        
        Scanner ler = new Scanner(System.in);

           System.out.println("Informe sua altura em metros");
           double h=ler.nextDouble();
           
           System.out.println("Informe seu sexo como f ou m:");
           String sexo = ler.next();
           
          
           if(sexo.equalsIgnoreCase("F")){
               double feminino = (62.1*h)-44.7;
                     System.out.println("Seu peso ideal(feminino) e: "+feminino);
           }else
               if(sexo.equalsIgnoreCase("M")){
               double masculino = (72.7*h)-58;
                     System.out.println("Seu peso ideal(masculino) e: "+masculino);
           }
    
}
}       
     
