
package com.mycompany.semana6;

import java.util.Scanner;

public class Exercicio2 {
    public static void main(String[]args){
        Scanner ler = new Scanner(System.in);
        int v1, v2;

        System.out.println("Informe o primeiro valor: ");
        v1= ler.nextInt();

        System.out.println("Informe o segundo valor: ");
        v2= ler.nextInt();

        System.out.println("Escolha uma operacao entre: 1-Adição, 2-Subtração, 3-Multiplicação e 4-Divisão");
        int op= ler.nextInt();
        switch (op){
            case 1:
                System.out.println("Adição");
            break;
            case 2:
                System.out.println("Subtração");
            break;
            case 3:
                System.out.println("Multiplicação");
            break;
            case 4:
                System.out.println("Divisão");
            break;
            default:
                System.out.println("Desculpe, opcao invalida");
        }

        if(op==1){
            int ad= v1+v2;
            System.out.println("O valor final e " +ad);
        }else{
            if(op==2){
                int sub= v1-v2;
                System.out.println("O valor final e " +sub);
            }else{
                if(op==3){
                    int mult;
                    mult = v2*v1;
                    System.out.println("O valor final e " +mult);
                }else{
                    if(op==4){
                        int div= v1/v2;
                        System.out.println("O valor final e " +div);
                    }
                }
            }
        }

    }
}