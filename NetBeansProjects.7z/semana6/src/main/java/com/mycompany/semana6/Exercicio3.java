
package com.mycompany.semana6;

import java.util.Scanner;

public class Exercicio3 {

    public static void main(String[]args){
        Scanner ler = new Scanner(System.in);
        int vcarro, vrua, v;

        System.out.println("Informe a velocidade do carro: ");
        vcarro= ler.nextInt();

        System.out.println("Informe a velocidade maxima da rua: ");
        vrua= ler.nextInt();

        v= vcarro -vrua;

        if((v >0) && (v<=10)){
            System.out.println("Multa de 100 reais, voce ultrapassou o limite de velocidade");
        }else
            if((v >= 11) && (v <= 30)){
               System.out.println("Multa de 150 reais, voce ultrapassou o limite de velocidade"); 
            }else
                if(v >= 31){
                    System.out.println("Multa de 300 reais, voce ultrapassou o limite de velocidade");
                } else
                    System.out.println("Dentro do limite de velocidade");
    }
        

    }
    

