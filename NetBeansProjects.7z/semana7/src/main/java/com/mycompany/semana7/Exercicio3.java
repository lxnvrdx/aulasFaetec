package com.mycompany.semana7;

import java.util.Scanner;


public class Exercicio3 {
    public static void main(String[]args){
        Scanner ler = new Scanner(System.in);

        int num, maior=0, menor=0, i=0;
 
        System.out.printf("Digite um numero:");
        num= ler.nextInt();
   
        menor= num;
        maior= num;
 
        for(i = 1; i < 10; i++){   
            System.out.printf("Digite um numero:");
            num= ler.nextInt();
 
            if(num > maior){ 
                maior= num;
            }
            if(num < menor){ 
                menor= num;
            }
        }

        System.out.printf ("\nO menor numero e: "+menor);
        System.out.printf ("\nE o maior numero e: "+maior);
    }
}