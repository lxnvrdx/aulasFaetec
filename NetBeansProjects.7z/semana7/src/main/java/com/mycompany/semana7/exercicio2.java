
package com.mycompany.semana7;

import java.util.Scanner;

public class exercicio2 {
        public static void main(String[]args){
 Scanner ler=new Scanner(System.in);
    String nome;
    int n1, n2;
    

 int i=0;
 
 for(i=0;i<5;i++){
 
     System.out.println("Informe nome: ");
     nome=ler.next();
     
     System.out.println("Informe a primeira nota: ");
     n1=ler.nextInt();
     
     System.out.println("Informe a segunda nota: ");
     n2=ler.nextInt();
     
     double media=(n1+n2)/2;
     
     if(media>=7){
         System.out.println("- Aprovado!");
     
     }else 
         if(media<7 && media>3){
             System.out.println("- Recuperacao!");
         }else{
             System.out.println("- Reprovado!");
         
         }
     
 }
}
}