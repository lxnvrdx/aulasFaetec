
package com.mycompany.semana7;

import java.util.Scanner;

public class Exercicio1 {
   
    
    public static void main(String[]args){
    
        Scanner ler=new Scanner(System.in);
        
                int soma = 0, num, cont = 0;
        while(cont<10){
        System.out.println("Informe um valor:  ");
        num= ler.nextInt();
        soma=soma+num;
        cont++;
    }
        System.out.println("Valor final da soma: "+soma);
}}
