package com.mycompany.semana7;

import java.util.Scanner;

public class exercicio5 {
    public static void main(String[]args){
        Scanner ler = new Scanner(System.in);
        int soma, n, f = 1, x = 0, contador = 0;

        System.out.printf("Entre com um numero para determinar a serie de fibonacci: ");
        n= ler.nextInt();

        while (contador < n){
            soma = f + x;
            x = f;
            f = soma;
            contador += 1;
            System.out.printf("%d ",x);
        }
    }
}