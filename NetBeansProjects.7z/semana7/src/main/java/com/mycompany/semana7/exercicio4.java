package com.mycompany.semana7;

import java.util.Scanner;


public class exercicio4 {
    public static void main(String[]args){
        Scanner ler = new Scanner(System.in);
        int fat, n;
        
        System.out.printf("Insira um valor para o qual deseja calcular seu fatorial: ");
        n= ler.nextInt();
 
        for(fat = 1; n>1; n=n-1){
            fat = fat * n;
        }
 
        System.out.printf("\nFatorial calculado: %d", fat);
    }
}