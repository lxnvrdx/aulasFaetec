
package com.mycompany.s10ex4;


import java.util.Scanner;

public class Exercicio4 {
    public static void main(String[] args) {
    Scanner ler = new Scanner(System.in);

    int i, cont = 0,ifvelha = 0, imvelha = 0;
    String fvelha = null;
    String mvelha = null;
   
    String []nome;
    nome= new String[10];
    int []sexo;
    sexo= new int[10];
    int[]idade;
    idade= new int[10];
  
 
        for(i = 0; i <2; i++){
            System.out.println("informe seu nome: ");
            nome[i]= ler.next();

            System.out.println("Informe sua idade: ");
           idade[i]= ler.nextInt();

            System.out.println("Informe seu sexo:");
            System.out.println("1 - FEMININO / 2 - MASCULINO");
            sexo[i]= ler.nextInt(); 

             if(sexo[i]==1){
              if(idade[i]>ifvelha){
                 
                  ifvelha = idade[i];
                  fvelha=nome[i];
              }}
              
            
              if(sexo[i]==2){
               if(idade[i]>imvelha){
                  imvelha=idade[i];
                  mvelha=nome[i];
               }}
//-------------------------------------------------------------
                if(idade[i]>=18){
                    cont=cont+1;
                }
        
        }
        System.out.println("Quantidade de pessoas maior de idade: " +cont);
        System.out.println("A mulher mais velha se chama: " +fvelha); 
        System.out.println("O homem mais velho se chama: "+mvelha);
    


}}