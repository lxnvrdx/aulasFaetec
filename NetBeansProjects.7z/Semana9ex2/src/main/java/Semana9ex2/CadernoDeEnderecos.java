
package Semana9ex2;

public class CadernoDeEnderecos {
    String nome, email, endereco, tel, data;
  
   
    public CadernoDeEnderecos(String data, String tel,String nome,String email, String endereco )  
    {  
        this.data=data;
        this.tel=tel;
        this.nome=nome;
        this.email=email;
        this.endereco=endereco;
        
    }  

    public void imprimeRegistro(){
		System.out.println("Nome: " + this.getNome());
		System.out.println("Telefone: " + this.getTel());
		System.out.println("Email: " + this.getEmail());
		System.out.println("Data de Aniversário: " + this.getData());
		System.out.println("Endereço : " + this.getEndereco());
		System.out.println("=============================================");
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getData() {
		return data;
	}
	public void setDataAniversario(String dataAniversario) {
		this.data = dataAniversario;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	
}   