/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.semana10;

import java.util.Scanner;

/**
 *
 * @author leonardo
 */
public class Exercicio1 {
       public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
	int idadeAnos, idadeTotal;
        
	System.out.print("Escreva sua idade: ");
	idadeAnos = entrada.nextInt();

	idadeTotal = idadeAnos * 365;
	System.out.print("Idade total em dias = " +idadeTotal);
	
    }
}

