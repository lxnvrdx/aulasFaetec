/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.semana10;

import java.util.Scanner;


public class Exercicio5 {
   public static void main(String[]args){
  Scanner ler = new Scanner(System.in);
  int contmulher=0;
  int pvelho=0, cont=0, media=0, contidade = 0, contm = 0, contid=0;
  String nomevelho = null;
  Pessoa p1=new Pessoa();
       int opcao = 0;
      
       
  
  do{
 System.out.println("INFORME O QUE DESEJA");
 System.out.println("SAIR(0) / CONTINUAR(1) ?");
 opcao=ler.nextInt();
   switch (opcao) {
   case 0:
       System.out.println("Saindo!");    
       System.exit(0);
   break;
   case 1: 
       System.out.println("Ccadastrando!");
       
  
  
       System.out.println("Quantos Pacientes quer cadastrar: ");
       int qnt=ler.nextInt();
  
       do{
       System.out.println("informe nome: ");
       p1.nome=ler.next();
       System.out.println("Informe a idade: ");
       p1.idade=ler.nextInt();
       System.out.println("Informe o sexo: ");
       System.out.println("1 - FEMININO / 2 - MASCULINO");
       p1.sexo=ler.nextInt();
       System.out.println("Informe o peso: ");
       p1.peso=ler.nextFloat();
       System.out.println("Iforme a altura: ");
       p1.altura=ler.nextFloat();
       
          
       
       
        if(p1.sexo==1){
        if(p1.altura>160 && p1.altura<170){
            if(p1.peso>70){
                contmulher = contmulher+1;
            }}}
        
        
         
            
       if(p1.sexo==2){
       contm=contm+1;
       contidade=(contidade+p1.idade); } 
       
       if(p1.idade>18 && p1.idade<25){
       contid=contid+1;
       }
       
       if(p1.idade>pvelho){
           pvelho=p1.idade;
           nomevelho=p1.nome;
       }
       
       cont=cont+1;
     
       }while(cont<qnt);
       
        media=(contidade/contm);
       
       System.out.println(" A quantidade de pacientes é: "+cont);
       System.out.println("-------------------------------------------------");
       System.out.println("A quantidade de pessoas com a idade entre 18 e 25 anos é: "+contid);
        System.out.println("-------------------------------------------------");
       System.out.println("o nome do paciente mais velho: "+nomevelho);
        System.out.println("-------------------------------------------------");
       System.out.println("A media de idade dos homens é: "+media);
        System.out.println("-------------------------------------------------");
       System.out.println("quantidade de mulheres com altura entre 1.60e1.70 e acima de 70kg: "+contmulher);
   }
  }while(opcao!=0);
   }}
