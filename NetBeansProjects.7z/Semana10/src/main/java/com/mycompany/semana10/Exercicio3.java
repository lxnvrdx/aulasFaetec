/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.semana10;

import java.util.Scanner;

/**
 *
 * @author leonardo
 */
public class Exercicio3 {
    
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int num, suce = 0, ant = 0;

        System.out.printf("Digite um numero:");
        num = ler.nextInt();
        
        ant = num - 1;
        suce = num + 1;

        System.out.printf ("\nAntecessor: " +ant+ " / Numero digitado: " +num+ " / Sucessor: " +suce);
    }   
}
