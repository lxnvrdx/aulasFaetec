
package com.mycompany.semana5exercicio1;

import java.util.Scanner;

public class Exercicio3 {
     
    public static void main(String[]args){
    
        Scanner ler = new java.util.Scanner(System.in);
        

    System.out.println("Informe o custo do automovel");
    double custocarro = ler.nextDouble();
           
    double imposto = custocarro * 0.45;
    double distribuidor = custocarro * 0.28;
     
    double custototal = custocarro + (distribuidor + imposto);
    
        System.out.printf("==========Custo total do automovel:  "+ custototal+"  ==========");
      
}}
