
package com.mycompany.semana5exercicio1;

import java.util.Scanner;

 public class Exercicio2 {
    
    public static void main(String[]args){
       
    Scanner entrada = new Scanner(System.in);
     int nota1=0; 
     int nota2=0;
     float media;
     String nome;
    
    System.out.println("Informe o nome do aluno");
    nome = entrada.next();
           
     
    System.out.println("Informe a primeira nota");
    nota1= entrada.nextInt();  
    
    System.out.println("Informe a segunda nota");
    nota2= entrada.nextInt();
    
    media = (nota1+nota2)/2;
    
        System.out.println("Nome do aluno\n"+nome);
      System.out.printf("O media do aluno é \n"+media);
   
}}
        
        
    

