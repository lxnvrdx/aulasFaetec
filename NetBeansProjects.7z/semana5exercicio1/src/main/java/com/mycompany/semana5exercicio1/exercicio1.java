
package com.mycompany.semana5exercicio1;

import java.util.Scanner;

public class exercicio1 {
    public static void main(String[]args){
       
    Scanner entrada = new Scanner(System.in);
     int num1=0; 
     int num2=0;
     int soma=0;
    
    System.out.println("Informe o primeiro numero da soma");
    num1= entrada.nextInt();  
    
    System.out.println("Informe o segundo numero da soma");
    num2= entrada.nextInt();
    
    soma = num1+num2;
    
      System.out.printf("O resultado da soma dos dois numeros é %d\n", soma);
   
}}
