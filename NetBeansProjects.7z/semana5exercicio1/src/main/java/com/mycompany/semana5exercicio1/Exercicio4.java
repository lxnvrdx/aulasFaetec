
package com.mycompany.semana5exercicio1;

import java.util.Scanner;

public class Exercicio4 {
    public static void main(String[]args){

        Scanner entrada = new Scanner(System.in);
        

        System.out.println("Informe a distancia percorrida: ");
        float distancia= entrada.nextFloat();
        System.out.println("Informe o tempo gasto: ");
        float tempo= entrada.nextFloat();
        System.out.println("Informe o consumo medio do carro: ");
        float consumo= entrada.nextFloat();

       float velocidadem= distancia/tempo;
       float totalconsumo= distancia/consumo;

       
        System.out.println("O consumo do carro foi de: " +totalconsumo+ " km/l");
        System.out.println("A velocidade media foi de: " +velocidadem+ " km/h");
    }
}
