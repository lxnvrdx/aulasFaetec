
package com.mycompany.semana9;

import java.util.Scanner;

public class Datateste {
    public static void main( String[] args ) {
        int dia = 0;
        int mes = 0;
        int ano = 0;
        Scanner s = new Scanner( System.in );
        System.out.println( "Digite o dia: " );        
        dia = s.nextInt();
        System.out.println( "Digite o mês: " );
        mes = s.nextInt();
        System.out.println( "Digite o ano: " );
        ano = s.nextInt();

        Data d;
        d = new Data(dia,mes,ano);
        System.out.println( "A data é: " + d.displayDate() );
    }

}