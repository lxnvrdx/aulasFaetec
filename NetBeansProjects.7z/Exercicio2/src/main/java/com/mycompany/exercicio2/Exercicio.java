
package com.mycompany.exercicio2;

import java.util.Scanner;

 public class Exercicio {
    
    public static void main(String[]args){
       
    Scanner entrada = new Scanner(System.in);
     int nota1=0; 
     int nota2=0;
     float media;
     String nome;
    
    System.out.println("Informe a primeira nota");
    nome = entrada.next();
           
     
    System.out.println("Informe a primeira nota");
    nota1= entrada.nextInt();  
    
    System.out.println("Informe a segunda nota");
    nota2= entrada.nextInt();
    
    media = (nota1+nota2)/2;
    
      System.out.printf("O resultado da soma dos dois numeros é %f\n", media);
   
}}
        
        
    